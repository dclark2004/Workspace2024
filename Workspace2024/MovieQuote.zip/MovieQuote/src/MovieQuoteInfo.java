//	Dawson Clark	1/16/24	Chapter 1 Activity 2 MovieQuoteInfo
public class MovieQuoteInfo {

	public static void main(String[] args) {
		System.out.println("\"Life is like a box of chocolates. You never know what you're gonna get.\" –Forrest Gump");

	}

}
