// Dawson Clark  1/16/2024	Intro Java program
public class Hello {

	public static void main(String[] args) {
		System.out.println("Hello from CSC 151");

	}

}
