// Dawson Clark Chapter 1 Acivity 1 SongLyrics-'Til You Can't by:Cody Johnson	1/16/24
public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("You can tell your old man");
		System.out.println("You'll do some largemouth fishing another time");
		System.out.println("You just got too much on your plate to bait and cast a line\r\n"
				+ "");

	}

}
